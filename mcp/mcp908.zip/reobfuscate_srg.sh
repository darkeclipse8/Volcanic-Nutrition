#!/bin/bash
python runtime/reobfuscate.py --srgnames "$@"
